<?php
	include $_SERVER["DOCUMENT_ROOT"]."/inc/header.php";
?>
		<div id="container">
			<div id="content"></div>
		</div>
<?php
	include $_SERVER['document_root'].'inc/footer.php';
?>