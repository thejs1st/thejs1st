<?php
	include 'inc/header.php';
?>
		<div id="container">
			<div id="content"></div>
		</div>
<?php
	include 'inc/footer.php';
?>